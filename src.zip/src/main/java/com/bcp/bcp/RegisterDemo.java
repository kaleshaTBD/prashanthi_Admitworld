package com.bcp.bcp;

public class RegisterDemo {

	private String name;
	
	private String emial;
	
	private String mobile;
	
	private String city;
	
	private String interest_study;
	
	private String message;
	
	private String interest_country;
	
	private String past_degree;
	
	private String exam1;
	
	private String exam2;
	
	

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getInterest_study() {
		return interest_study;
	}

	public void setInterest_study(String interest_study) {
		this.interest_study = interest_study;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getInterest_country() {
		return interest_country;
	}

	public void setInterest_country(String interest_country) {
		this.interest_country = interest_country;
	}

	public String getPast_degree() {
		return past_degree;
	}

	public void setPast_degree(String past_degree) {
		this.past_degree = past_degree;
	}

	public String getExam1() {
		return exam1;
	}

	public void setExam1(String exam1) {
		this.exam1 = exam1;
	}

	public String getExam2() {
		return exam2;
	}

	public void setExam2(String exam2) {
		this.exam2 = exam2;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmial() {
		return emial;
	}

	public void setEmial(String emial) {
		this.emial = emial;
	}
	
	
}
